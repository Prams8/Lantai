# LANTAI Android

1. Buat repo baru di GitHub, upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** > **Build APK** > **Run workflow** (atau tunggu otomatis setelah upload).
3. Setelah hijau, buka run-nya, unduh artifact **LANTAI-apk**, ekstrak, kirim `app-debug.apk` ke HP, lalu install.
